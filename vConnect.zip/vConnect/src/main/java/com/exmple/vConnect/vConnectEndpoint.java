package com.exmple.vConnect;

import java.util.List;

import com.google.api.server.spi.config.Api;
import com.google.api.server.spi.config.ApiMethod;
import com.google.api.server.spi.config.ApiMethod.HttpMethod;
import com.google.api.server.spi.config.Named;
import com.googlecode.objectify.cmd.Query;

@Api(name ="vconnectep", version = "v1", scopes = {Constants.EMAIL_SCOPE }, clientIds = {Constants.WEB_CLIENT_ID, Constants.API_EXPLORER_CLIENT_ID },
description = "API for vConnectEndpoint")
public class vConnectEndpoint {
	@ApiMethod(name = "saveData", path = "saveData", httpMethod = HttpMethod.GET)
    public Profile saveData(@Named("name") String name, @Named("email") String email,@Named("profession") String profession,@Named("cell") String cell,@Named("about") String about) {
    	Profile p= new Profile(name,email,profession,cell,about);
    	ConnectService.ofy().save().entity(p).now();
        return p;
    }
	@ApiMethod(name = "getRecords", path = "getRecords", httpMethod = HttpMethod.GET)
    public List<Profile> getRecords(){
		Query<Profile> q=ConnectService.ofy().load().type(Profile.class);
		return q.list();
    }
}
