package com.exmple.vConnect;

import com.googlecode.objectify.annotation.Entity;
import com.googlecode.objectify.annotation.Id;
@Entity
public class Profile {
	@Id
	String email;
	String name;
	String profession;
	String about;
	String cell;
  public Profile()
  {}
	public Profile(String displayName, String mainEmail, String pfrn,String ph_no,String about) {
  	name = displayName.toUpperCase();
  	email = mainEmail.toUpperCase();
  	profession= pfrn.toUpperCase();
  	this.about=about;
  	cell=ph_no;
     }

public String getName() {
		return name;
	}
	public String getCell() {
		return cell;
	}

	public String getEmail() {
	return email;
	}
	public String getProfession() {
		return profession;
	}
  public String getAbout()
  {
  	return about;
  }
 
}
