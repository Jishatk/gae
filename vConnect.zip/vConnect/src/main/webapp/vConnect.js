function init(){
	var rootpath = "//" + window.location.host + "/_ah/api";
	gapi.client.load('vconnectep', 'v1', loadCallback, rootpath);
}
function loadCallback (){	
  	btn = document.getElementById("imageField");
	btn.onclick= function(){saveData();};
}
function saveData(){
	// Get the name from the name_field element
	var name = document.getElementById("name_field").value;
	var email = document.getElementById("email_field").value;
	var profession = document.getElementById("profession_field").value;
	var  cell= document.getElementById("cell_field").value;
	var about=document.getElementById("about_area").value;
	var request = gapi.client.vconnectep.saveData({'name': name, 'email' : email,'profession':profession,'cell':cell,'about':about});
	 request.execute(saveCallback);
	}
function saveCallback(response){
		alert("The record has been saved! You can check the inserted record from the admin console!");
		window.location="index.html";
		}


